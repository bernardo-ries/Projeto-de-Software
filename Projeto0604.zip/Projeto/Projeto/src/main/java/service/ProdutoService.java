package service;

import com.example.projeto.model.Produto;
import com.example.projeto.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

@Service
public class ProdutoService {
    private final ProdutoRepository produtoRepository;

    public ProdutoService(ProdutoRepository produtoRespository) {
        this.produtoRepository = produtoRespository;
    }

    public void salvar(Produto produto) {
        if (produto.getNome() == null || produto.getNome().isBlank()) {
            throw new RuntimeException("O nome do prduto é obrigatório");
        }
        if(produto.getValor() <= 0 ){
            throw new RuntimeException("O valor deve ser maior que zero");
        }
        produtoRepository.save(produto);
    }
}
